package com.example.repository;

import com.example.domain.Favourite;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

import java.nio.file.FileVisitOption;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

//@DataJpaTest
//@AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.NONE)
@ExtendWith(MockitoExtension.class)
public class FavouriteRepositoryTest {
    @Mock
    public FavouriteRepository favouriteRepository;
    @Test
    public void givenSongShouldReturnSavedSong(){
        Favourite favourite=new Favourite(1,"XYZ","ABC");
        favouriteRepository.save(favourite);
        Favourite favourite1 = new Favourite();
        if(favouriteRepository.findById(favourite.getId()).isPresent()) {
   favourite1 = favouriteRepository.findById(favourite.getId()).get();
        }
        assertNotNull(favourite1);
        assertEquals(favourite1.getSongName(),favourite1.getSongName());
    }
    @Test
    public void givenSongShouldReturnAllSongs(){
        List<Favourite> favouriteList=(List<Favourite>) favouriteRepository.findAll();
        assertNotNull(favouriteList);
    }
    @Test
    public void givenSongShouldBeDeletedAndSongShouldBeReturned(){
        Favourite favourite=new Favourite(1,"XYZ","ABC");
        Favourite favourite2=new Favourite(2,"XYZ","ABC");
        favouriteRepository.save(favourite);
        favouriteRepository.save(favourite2);
        favouriteRepository.deleteById(favourite2.getId());
        assertEquals(favourite2.getId(),favourite2.getId());
    }

}
