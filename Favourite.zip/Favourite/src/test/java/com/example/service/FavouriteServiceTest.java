package com.example.service;

import com.example.domain.Favourite;
import com.example.repository.FavouriteRepository;
import org.junit.jupiter.api.Test;

import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class FavouriteServiceTest {
    @Mock
    private FavouriteRepository favouriteRepository;

    @InjectMocks
    private FavouriteServiceImp favouriteService;
    @Test
    public void givenSongToSaveShouldReturnSong(){
        Favourite favourite=new Favourite(1,"XYZ","ABC");
        when(favouriteRepository.save(any())).thenReturn(favourite);
        favouriteService.saveFavourite(favourite);
        verify(favouriteRepository,times(1)).save(any());
    }
    @Test
    public void givenUserShouldReturnAllSongs(){
        List<Favourite> favouritesList=favouriteService.getAllFavourite();
        verify(favouriteRepository,times(1)).findAll();
    }
    @Test
    public void givenSongToDeleteTheSongAndReturnTheSong(){
        Favourite favourite=new Favourite(1,"XYZ","ABC");
        favouriteRepository.deleteById(favourite.getId());
        verify(favouriteRepository,times(1)).deleteById(any());
    }

}
