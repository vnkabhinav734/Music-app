package com.example.controller;

import com.example.domain.Favourite;
import com.example.service.FavouriteService;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
import org.springframework.boot.autoconfigure.orm.jpa.HibernateJpaAutoConfiguration;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.http.MediaType;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultHandlers;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;


import java.util.List;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@ExtendWith(MockitoExtension.class)
public class FavouriteControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @Mock
    private FavouriteService favouriteService;
    private Favourite favourite;
    private List<Favourite> favouriteList;

    @InjectMocks
    private FavouriteController favouriteController;

    @BeforeEach
    public void setup(){
        favourite=new Favourite(1,"XYZ","ABC");
        mockMvc= MockMvcBuilders.standaloneSetup(favouriteController).build();
    }
    @Test
    public void givenSongToSaveShouldReturnSavedSong() throws Exception {
        when(favouriteService.saveFavourite(any())).thenReturn(favourite);
        mockMvc.perform(post("/api/v1/favourite")
                .contentType(MediaType.APPLICATION_JSON)
                .content(asJsonString(favourite)))
                .andExpect(status().isCreated());
        verify(favouriteService,times(1)).saveFavourite(any());
    }
    @Test
    public void givenBlogToGetAllSongs() throws Exception {
        when(favouriteService.getAllFavourite()).thenReturn(favouriteList);
        mockMvc.perform(MockMvcRequestBuilders.get("/api/v1/favourites")
                .contentType(MediaType.APPLICATION_JSON)
                .content(asJsonString(favourite)))
                .andDo(MockMvcResultHandlers.print());
        verify(favouriteService,times(1)).getAllFavourite();
    }
    @Test
    public void givenSongShouldBeDeletedAndReturnTheSong() throws Exception {
        when(favouriteService.deleteByid(favourite.getId())).thenReturn(favourite);
        mockMvc.perform(MockMvcRequestBuilders.delete("/api/v1/favourites/1")
                .contentType(MediaType.APPLICATION_JSON)
                .content(asJsonString(favourite)))
                .andExpect(status().isGone());
        verify(favouriteService,times(1)).deleteByid(favourite.getId());
    }
    private static String asJsonString(final Object obj) {
        try {
            return new ObjectMapper().writeValueAsString(obj);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

}
