package com.example.controller;


import com.example.domain.Favourite;
import com.example.service.FavouriteService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("api/v1")
public class FavouriteController {

    private FavouriteService favouriteService;
    @Autowired
    public FavouriteController(FavouriteService favouriteService) {
        this.favouriteService = favouriteService;
    }
    @PostMapping("/favourite")
    @CrossOrigin(origins = "http://localhost:4200")
    public ResponseEntity<Favourite> saveFavourites(@RequestBody Favourite favourite){
        Favourite savedFavourites = favouriteService.saveFavourite(favourite);
        return new ResponseEntity<>(savedFavourites, HttpStatus.CREATED);
    }

    @GetMapping("/favourites")
    @CrossOrigin(origins = "http://localhost:4200")
    public ResponseEntity<List<Favourite>> getAllFavourites(){
        return  new ResponseEntity<List<Favourite>>((List<Favourite>) favouriteService.getAllFavourite(),HttpStatus.OK);
    }
  @DeleteMapping("/favourites/{id}")
  @CrossOrigin(origins = "http://localhost:4200")
    public ResponseEntity<Favourite> delete(@PathVariable int id) {

        return new ResponseEntity<Favourite>((Favourite ) favouriteService.deleteByid(id), HttpStatus.GONE);

    }


}
