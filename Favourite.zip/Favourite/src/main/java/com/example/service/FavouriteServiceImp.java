package com.example.service;


import com.example.domain.Favourite;
import com.example.repository.FavouriteRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PathVariable;

import java.util.List;
import java.util.Optional;

@Service
public class FavouriteServiceImp implements FavouriteService {

    private FavouriteRepository favouriteRepository;

    @Autowired
    public FavouriteServiceImp(FavouriteRepository favouriteRepository) {
        this.favouriteRepository = favouriteRepository;
    }

    @Override
    public Favourite saveFavourite(Favourite favourite) {
        return favouriteRepository.save(favourite);
    }

    @Override
    public List<Favourite> getAllFavourite() {
        return (List<Favourite>) favouriteRepository.findAll();
    }

    @Override
    public Favourite deleteByid(int id) {
        Favourite fav=null;
        Optional optional=favouriteRepository.findById(id);
        if(optional.isPresent()) {
            fav = favouriteRepository.findById((id)).get();
            favouriteRepository.delete(fav);
        }
        return (Favourite) fav;

    }
}
