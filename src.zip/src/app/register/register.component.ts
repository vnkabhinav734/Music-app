import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { User } from '../Model/User';
import { AuthService } from '../service/auth.service';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {

  constructor(private authService:AuthService) { }
  form=new FormGroup({
    firstname:new FormControl('',Validators.required),
    lastname:new FormControl('',Validators.required),
    // email:new FormControl('',Validators.email),
    email:new FormControl('',Validators.required),
    username:new FormControl('',Validators.required),
    password:new FormControl('',Validators.required),
    confirmpassword:new FormControl('',Validators.required)
  });
  message = '';
  input1 = '';
  input2 = this.input1;
  x:User;
  ngOnInit(): void {
    
  }
  getChange(event) {
    this.input2=event;
  }
  Register() {
    if(this.form.get('password').value==this.form.get('confirmpassword').value)
    {
      this.x=new User();
      this.x.firstName=this.form.get('firstname').value;
      this.x.lastName=this.form.get('lastname').value;
      this.x.email=this.form.get('email').value;
      this.x.username=this.form.get('username').value;
      this.x.password=this.form.get('password').value;
      this.authService.register(this.x).subscribe(
        data=>{this.message=data;},
        error=>{this.message=error}
      );
      alert("Registered successfully!");
    } else {
      // alert("Password must be same on confirm password and password field");
      alert("Invalid Entry");
    }
    
  }
}
