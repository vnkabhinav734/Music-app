export class LogIn {
    username?: string;
    password?: string;
}