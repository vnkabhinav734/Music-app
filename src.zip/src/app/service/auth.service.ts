import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { User } from '../Model/User';

@Injectable({
  providedIn: 'root'
})
export class AuthService {

  constructor(private http: HttpClient) { }

  register(user:User): Observable<any> {
    // return this.http.post<User>("http://localhost:3000/Auth/register",user);
    console.log(user);
    return this.http.post<User>("http://localhost:9090/api/v1/user",user);
  }

  logIn(user:User): Observable<any> {
    return this.http.post<User>("http://localhost:3000/Auth/login",user);
  }
}
