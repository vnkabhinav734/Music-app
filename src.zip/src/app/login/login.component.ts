import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { LogIn } from '../Model/LogIn';
import { AuthService } from '../service/auth.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  constructor(private authService:AuthService) { }
  form=new FormGroup({
    uid:new FormControl('',Validators.required),
    pass:new FormControl('',Validators.required)
  });
  x:LogIn;
  message = '';
  ngOnInit(): void {
  }
  Login() {
    this.x=new LogIn();
    this.x.username=this.form.get('uid').value;
    this.x.password=this.form.get('pass').value;
    this.authService.logIn(this.x).subscribe(
      data=>{this.message=data},
      error=>{this.message=error}
    );
    alert("Logged in successfully!");
  }
}
