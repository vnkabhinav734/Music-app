package com.MusicApp.registration.Repository;

import com.MusicApp.registration.model.User;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

/**
 * @Repository marks the specific class as a Data Access Object
 */
@Repository
public interface UserRepository extends CrudRepository<User, Integer> {
}
