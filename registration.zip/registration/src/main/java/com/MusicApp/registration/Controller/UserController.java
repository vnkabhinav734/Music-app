package com.MusicApp.registration.Controller;

import com.MusicApp.registration.model.User;
import com.MusicApp.registration.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1")
public class UserController {
    private UserService userService;

    @Autowired
    public UserController(UserService userService) {
        this.userService = userService;
    }
    /**
     * save a new user
     */
    @PostMapping("/user")
    @CrossOrigin(origins = "http://localhost:4200")
    public ResponseEntity<User> saveUser(@RequestBody User user) {
        User savedUser = userService.saveUser(user);
        return new ResponseEntity<>(savedUser, HttpStatus.CREATED);
    }
    @GetMapping("/loginuser")
    @CrossOrigin(origins="http://localhost:4200")
    public ResponseEntity<List<User>> getUser(){
        return new ResponseEntity<List<User>>((List<User>) userService.getAllUsers(), HttpStatus.OK);
    }
}
