package com.jwtservice.jwtservice.service;

import com.jwtservice.jwtservice.domain.User;
import com.jwtservice.jwtservice.exception.UserNotFoundException;

public interface UserService {
    User findByUsernameAndPassword(String username, String password) throws UserNotFoundException;
}
