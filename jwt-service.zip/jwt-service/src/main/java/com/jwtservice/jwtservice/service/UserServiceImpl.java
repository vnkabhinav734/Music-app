package com.jwtservice.jwtservice.service;

import com.jwtservice.jwtservice.domain.User;
import com.jwtservice.jwtservice.exception.UserNotFoundException;
import com.jwtservice.jwtservice.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

@Service
public class UserServiceImpl implements UserService {
    private final UserRepository userRepository;
    @Value("${app.service.message1}")
    private String message1;
    @Autowired
    public UserServiceImpl(UserRepository userRepository) {
        super();
        this.userRepository = userRepository;
    }


    @Override
    public User findByUsernameAndPassword(String username, String password) throws UserNotFoundException {
        User authUser = userRepository.findByUsernameAndPassword(username, password);
        if (authUser == null) {
            throw new UserNotFoundException(message1);
        }
        return authUser;
    }

    }

