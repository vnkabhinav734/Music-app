package com.jwtservice.jwtservice.bootstrap;

import com.jwtservice.jwtservice.domain.User;
import com.jwtservice.jwtservice.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;

public class AppDataBootstrap implements CommandLineRunner {
    /**
     * Use constructor based DI to inject UserRepository here
     */
    private final UserRepository userRepository;
    @Autowired
    public AppDataBootstrap(UserRepository userRepository) {
        this.userRepository = userRepository;
    }
    @Value("${app.seeddata.username1}")
    private String username1;

    @Value("${app.seeddata.username2}")
    private String username2;

    @Value("${app.seeddata.password1}")
    private String password1;

    @Value("${app.seeddata.password2}")
    private String password2;

    @Value("${app.seeddata.logMessage}")
    private String logMessage;
    @Override
    public void run(String... args) throws Exception {
        User user1 = new User(username1, password1);
        User user2 = new User(username2, password2);
        userRepository.save(user1);
        userRepository.save(user2);

    }
}
