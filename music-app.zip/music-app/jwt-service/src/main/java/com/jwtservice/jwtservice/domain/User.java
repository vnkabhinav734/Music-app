package com.jwtservice.jwtservice.domain;

import org.springframework.boot.autoconfigure.domain.EntityScan;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="userDetails")
public class User {
    /**
     * @Id annotation to make id variable as Primary key
     */
    @Id
    @Column(name = "username", length = 50)
    private String username;

    @Column(name = "password")
    private String password;


    /**
     * default constructor
     */
    public User() {
        super();
    }

    /**
     * parameterized constructor
     */
    public User(String username, String password) {
        super();
        this.username = username;
        this.password = password;
    }


    public String getusername() {
        return username;
    }

    public void setusername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
}
