package com.MusicApp.registration.service;

import com.MusicApp.registration.model.User;

import java.util.List;

public interface UserService {
    /**
     * AbstractMethod to save a user
     */
    User saveUser(User user);
}
