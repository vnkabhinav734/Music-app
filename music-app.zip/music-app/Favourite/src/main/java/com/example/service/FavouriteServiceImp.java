package com.example.service;


import com.example.domain.Favourite;
import com.example.repository.FavouriteRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class FavouriteServiceImp implements FavouriteService {

    private FavouriteRepository favouriteRepository;


    public FavouriteServiceImp(FavouriteRepository favouriteRepository) {
        this.favouriteRepository = favouriteRepository;
    }

    @Override
    public Favourite saveFavourite(Favourite favourite) {
        return favouriteRepository.save(favourite);
    }

    @Override
    public List<Favourite> getAllFavourite() {
        return (List<Favourite>) favouriteRepository.findAll();
    }

    @Override
    public Favourite deleteById(int id) {
        Favourite fav= (Favourite) favouriteRepository.findById(id).get();
        favouriteRepository.deleteById(id);
        return (Favourite) fav;

    }
}
