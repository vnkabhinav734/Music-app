package com.example.service;

import com.example.domain.Favourite;

import java.util.List;

public interface FavouriteService {
    Favourite saveFavourite(Favourite favourite);
    List<Favourite> getAllFavourite();
    Favourite deleteById(int id);
}
